//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by JobLab.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_JOBLAB                      103
#define IDI_JOBLAB                      105
#define IDB_BITMAP1                     106
#define IDB_BITMAP2                     107
#define IDC_PERPROCESSUSERTIMELIMIT     1000
#define IDC_PERJOBUSERTIMELIMIT         1001
#define IDC_MINWORKINGSETSIZE           1002
#define IDC_MAXWORKINGSETSIZE           1004
#define IDC_ACTIVEPROCESSLIMIT          1005
#define IDC_PRIORITYCLASS               1006
#define IDC_SCHEDULINGCLASS             1007
#define IDC_RESTRICTACCESSTOOUTSIDEUSEROBJECTS 1008
#define IDC_RESTRICTREADINGCLIPBOARD    1009
#define IDC_RESTRICTWRITINGCLIPBOARD    1010
#define IDC_RESTRICTEXITWINDOW          1011
#define IDC_RESTRICTCHANGINGSYSTEMPARAMETERS 1012
#define IDC_TERMINATE                   1013
#define IDC_STATUS                      1014
#define IDC_APPLYLIMITS                 1015
#define IDC_RESTRICTDESKTOPS            1016
#define IDC_RESTRICTDISPLAYSETTINGS     1017
#define IDC_RESTRICTGLOBALATOMS         1018
#define IDC_CHILDPROCESSESCANBREAKAWAYFROMJOB 1019
#define IDC_TERMINATEPROCESSONEXCEPTIONS 1020
#define IDC_MAXCOMMITPERJOB             1021
#define IDC_MAXCOMMITPERPROCESS         1022
#define IDC_AFFINITYMASK                1023
#define IDC_CHILDPROCESSESDOBREAKAWAYFROMJOB 1024
#define IDC_PROCESSID                   1025
#define IDC_ASSIGNPROCESSTOJOB          1026
#define IDC_PRESERVEJOBTIMEWHENAPPLYINGLIMITS 1027
#define IDC_SPAWNCMDINJOB               1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
